package com.alexmercerind.flutter_media_metadata_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
