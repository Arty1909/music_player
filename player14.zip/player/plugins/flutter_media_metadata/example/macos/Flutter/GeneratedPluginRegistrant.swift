//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import flutter_media_metadata

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FlutterMediaMetadataPlugin.register(with: registry.registrar(forPlugin: "FlutterMediaMetadataPlugin"))
}
