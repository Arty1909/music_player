#import <Flutter/Flutter.h>

@interface FlutterMediaMetadataPlugin : NSObject<FlutterPlugin>
@end
