// main.dart
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'style.dart';

// ✅ Стало:
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ensureBoxes();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: texts['app'] ?? 'Glass Player',
      theme: ThemeData(useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    ensureBoxes();
    ensureAudio();
  }

  @override
  Widget build(BuildContext context) {
    final el = elOf(context);

    return Scaffold(
      drawer: appDrawer(el),
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: appBackground(),
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(el * 1.2),
            child: Column(
              children: [
                topBar(context, el),
                SizedBox(height: el),
                Expanded(
                  child: glass(
                    scrollY(
                      ValueListenableBuilder<String>(
                        valueListenable: currentPage,
                        builder: (_, page, __) {
                          final content = page == 'playlists'
                              ? playlistsView(el)
                              : page == 'playlist'
                              ? playlistView(el)
                              : page == 'queue'
                              ? queueView(el)
                              : libraryView(el);

                          return content;
                        },
                      ),
                    ),
                    el,
                  ),
                ),
                SizedBox(height: el * .6),
                glass(miniPlayer(el), el),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
