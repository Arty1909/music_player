// main.dart
import 'package:flutter/material.dart';
import 'style.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ensureBoxes();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: texts['app'] ?? 'Glass Player',
      theme: ThemeData(useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    ensureBoxes();
    ensureAudio();
  }

  @override
  Widget build(BuildContext context) {
    final el = elOf(context);

    return Scaffold(
      drawer: ValueListenableBuilder<bool>(
        valueListenable: isSelectionMode,
        builder: (_, isSelecting, __) =>
            isSelecting ? const SizedBox.shrink() : appDrawer(el),
      ),
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: appBackground(),
        child: SafeArea(
          child: ValueListenableBuilder<String>(
            valueListenable: currentPage,
            builder: (context, page, _) {
              if (page == 'now') {
                return Padding(
                  padding: EdgeInsets.all(el * 1.2),
                  child: nowPlayingView(el),
                );
              }

              return Padding(
                padding: EdgeInsets.all(el * 1.2),
                child: Column(
                  children: [
                    topBar(context, el), // topBar теперь сам будет меняться
                    SizedBox(height: el),
                    Expanded(
                      child: glass(
                        ValueListenableBuilder<String>(
                          valueListenable: currentPage,
                          builder: (_, page, __) {
                            Widget content;
                            bool needsScrollY = false;
                            if (page == 'playlists') {
                              content = playlistsView(el);
                              needsScrollY = true;
                            } else if (page == 'playlist') {
                              content = playlistView(el);
                              needsScrollY = false;
                            } else if (page == 'queue') {
                              content = queueView(el);
                              needsScrollY = false;
                            } else {
                              content = libraryView(el); // По умолчанию 'home'
                              needsScrollY = true;
                            }

                            return needsScrollY ? scrollY(content) : content;
                          },
                        ),
                        el,
                      ),
                    ),
                    SizedBox(height: el * .6),

                    // --- ИЗМЕНЕНИЕ: Оборачиваем плеер в слушатель isSelectionMode ---
                    ValueListenableBuilder<bool>(
                      valueListenable: isSelectionMode,
                      builder: (context, isSelecting, _) {
                        if (isSelecting) {
                          return const SizedBox.shrink(); // Скрываем плеер
                        }

                        // Старая логика отображения плеера
                        return ValueListenableBuilder<String?>(
                          valueListenable: currentId,
                          builder: (_, id, __) {
                            if (id == null || page == 'now') {
                              return const SizedBox.shrink();
                            }

                            return glass(
                              InkWell(
                                onTap: () => setPage('now'),
                                child: miniPlayer(el),
                              ),
                              el,
                            );
                          },
                        );
                      },
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
