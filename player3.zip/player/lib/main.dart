// main.dart
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'style.dart';

// ✅ Стало:
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ensureBoxes();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: texts['app'] ?? 'Glass Player',
      theme: ThemeData(useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final el = elOf(context);

    return Scaffold(
      drawer: appDrawer(el),
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: appBackground(),
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.all(el * 1.2),
            child: Column(
              children: [
                topBar(context, el), // меню, поиск, sort, Add (в хедере)
                SizedBox(height: el), // было el * 1.2
                SizedBox(height: el),
                Expanded(
                  child: glass(
                    scrollY(
                      libraryView(el),
                    ), // вертикальный скролл + растяжение по высоте
                    el,
                  ),
                ),
                SizedBox(height: el * .6),
                glass(miniPlayer(el), el),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
