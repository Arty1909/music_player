// style.dart
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path/path.dart' as p;
import 'package:flutter/foundation.dart' show kIsWeb;

/* ========= data ========= */

final Map<String, String> texts = {
  'app': 'Glass Player',
  'home': 'Listen now',
  'library': 'Library',
  'playlists': 'Playlists',
  'queue': 'Queue',
  'settings': 'Settings',
  'addMusic': 'Add music',
  'createPlaylist': 'Create playlist',
  'importFiles': 'Import files',
  'importFolder': 'Import folder',
  'sort': 'Sort',
  'search': 'Search',
  'byName': 'By name',
  'byArtist': 'By artist',
  'byDate': 'Recently added',
  'byDuration': 'By duration',
  'noTracks': 'No tracks yet',
  'importCta': 'Tap + to add',
  // демо-подписи мини-плеера
  'trackSample': 'Psychedelic',
  'artistSample': 'D3m0n X Diablo',
};

final Map<String, Color> colors = {
  'bg1': const Color(0xFFBFD9FF),
  'bg2': const Color(0xFF9FC3FF),
  'glass': const Color(0x44FFFFFF), // более прозрачное стекло
  'glassBorder': const Color(0x22FFFFFF),
  'text': Colors.white,
  'textDim': Colors.white70,
  'accent': const Color(0xFF7A4DFF),
  'accentDim': const Color(0x337A4DFF),
  'shadow': const Color(0x33000000),
};

final Map<String, double> sizes = {
  'minEl': 8,
  'maxEl': 24,
  'blur': 20,
  'radiusK': 2.4,
};

final Map<String, IconData> iconsMap = {
  'menu': Icons.menu_rounded,
  'more': Icons.more_horiz_rounded,
  'search': Icons.search_rounded,
  'add': Icons.add_rounded,
  'playlist': Icons.queue_music_rounded,
  'queue': Icons.queue_play_next_rounded,
  'settings': Icons.settings_rounded,
  'sort': Icons.sort_rounded,
  'play': Icons.play_arrow_rounded,
  'pause': Icons.pause_rounded,
};

Widget scrollY(Widget child) {
  return LayoutBuilder(
    builder: (ctx, c) => SingleChildScrollView(
      padding: EdgeInsets.zero,
      physics: const ClampingScrollPhysics(),
      child: ConstrainedBox(
        constraints: BoxConstraints(
          minHeight: c.maxHeight,
        ), // заполняем доступную высоту
        child: child,
      ),
    ),
  );
}

/* ========= registries ========= */

typedef IconButtonBuilder =
    Widget Function(IconData icon, VoidCallback onTap, double el);

final Map<String, IconButtonBuilder> iconButtons = {
  'circle': (icon, onTap, el) => Material(
    type: MaterialType.transparency,
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(el * (sizes['radiusK'] ?? 2.4)),
      child: Container(
        width: el * 2.6,
        height: el * 2.6,
        decoration: BoxDecoration(
          color: colors['glass'],
          borderRadius: BorderRadius.circular(el * (sizes['radiusK'] ?? 2.4)),
          border: Border.all(color: colors['glassBorder']!, width: 1),
          boxShadow: [
            BoxShadow(
              color: colors['shadow']!,
              blurRadius: el,
              offset: Offset(0, el * .3),
            ),
          ],
        ),
        alignment: Alignment.center,
        child: Icon(icon, size: el * 1.6, color: colors['text']),
      ),
    ),
  ),
};

final Map<String, dynamic> buttons = {
  'icon': (IconData icon, VoidCallback onTap, double el) =>
      iconButtons['circle']!(icon, onTap, el),

  'pill': (String text, IconData icon, VoidCallback onTap, double el) =>
      Material(
        type: MaterialType.transparency,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(el * (sizes['radiusK'] ?? 2.4)),
          child: Container(
            padding: EdgeInsets.symmetric(
              horizontal: el * 1.2,
              vertical: el * .8,
            ),
            decoration: BoxDecoration(
              color: colors['glass'],
              borderRadius: BorderRadius.circular(
                el * (sizes['radiusK'] ?? 2.4),
              ),
              border: Border.all(color: colors['glassBorder']!, width: 1),
              boxShadow: [
                BoxShadow(
                  color: colors['shadow']!,
                  blurRadius: el,
                  offset: Offset(0, el * .3),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: el * 1.4, color: colors['text']),
                SizedBox(width: el * .6),
                Text(
                  text,
                  style: TextStyle(color: colors['text'], fontSize: el * 1.05),
                ),
              ],
            ),
          ),
        ),
      ),
};

/* ========= helpers ========= */

double elOf(BuildContext ctx) {
  final s = MediaQuery.of(ctx).size;
  final base = min(s.width, s.height) / 24;
  final mn = sizes['minEl'] ?? 8.0, mx = sizes['maxEl'] ?? 28.0;
  return base.clamp(mn, mx);
}

BoxDecoration appBackground() => BoxDecoration(
  gradient: LinearGradient(
    colors: [colors['bg1']!, colors['bg2']!],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  ),
);

Widget glass(Widget child, double el) {
  final r = el * (sizes['radiusK'] ?? 2.4);
  return ClipRRect(
    borderRadius: BorderRadius.circular(r),
    child: BackdropFilter(
      filter: ImageFilter.blur(
        sigmaX: sizes['blur'] ?? 20,
        sigmaY: sizes['blur'] ?? 20,
      ),
      child: Material(
        type: MaterialType.transparency,
        child: Container(
          padding: EdgeInsets.all(el * 1.2),
          decoration: BoxDecoration(
            color: colors['glass'],
            borderRadius: BorderRadius.circular(r),
            border: Border.all(color: colors['glassBorder']!, width: 1),
            boxShadow: [
              BoxShadow(
                color: colors['shadow']!,
                blurRadius: el * 1.4,
                offset: Offset(0, el * .4),
              ),
            ],
          ),
          child: child,
        ),
      ),
    ),
  );
}

/* ========= reusable UI ========= */

Drawer appDrawer(double el) {
  final items = [
    {'icon': iconsMap['playlist']!, 'title': texts['library']!},
    {'icon': iconsMap['playlist']!, 'title': texts['playlists']!},
    {'icon': iconsMap['queue']!, 'title': texts['queue']!},
    {'icon': iconsMap['settings']!, 'title': texts['settings']!},
  ];

  return Drawer(
    backgroundColor: Colors.transparent,
    child: SafeArea(
      child: Padding(
        padding: EdgeInsets.all(el * 1.2),
        child: glass(
          ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_, __) => SizedBox(height: el * .6),
            itemBuilder: (_, i) => ListTile(
              leading: Icon(
                items[i]['icon'] as IconData,
                color: colors['text'],
              ),
              title: Text(
                items[i]['title'] as String,
                style: TextStyle(color: colors['text']),
              ),
              onTap: () {},
            ),
          ),
          el,
        ),
      ),
    ),
  );
}

Widget topBar(BuildContext ctx, double el) {
  final iconBtn =
      buttons['icon'] as Widget Function(IconData, VoidCallback, double);
  final pillBtn =
      buttons['pill']
          as Widget Function(String, IconData, VoidCallback, double);

  return Builder(
    // <-- добавили
    builder: (inner) => Row(
      children: [
        iconBtn(
          iconsMap['menu']!,
          () => Scaffold.of(inner).openDrawer(),
          el,
        ), // <-- inner
        SizedBox(width: el),
        Expanded(
          child: Text(
            texts['home']!,
            style: TextStyle(
              fontSize: el * 1.6,
              color: colors['text'],
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        Expanded(
          flex: 2,
          child: glass(
            SizedBox(
              height: el * 3.4,
              child: Row(
                children: [
                  Icon(
                    iconsMap['search']!,
                    color: colors['textDim'],
                    size: el * 1.6,
                  ),
                  SizedBox(width: el),
                  Expanded(
                    child: Text(
                      texts['search']!,
                      style: TextStyle(
                        color: colors['textDim'],
                        fontSize: el * 1.05,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            el,
          ),
        ),
        SizedBox(width: el),
        iconBtn(
          iconsMap['sort']!,
          () => openSortSheet(inner, el),
          el,
        ), // <-- inner
        SizedBox(width: el),
        pillBtn(
          texts['addMusic']!,
          iconsMap['add']!,
          () => openAddMenu(inner, el),
          el,
        ), // <-- inner
        SizedBox(width: el),
        iconBtn(iconsMap['more']!, () {}, el),
      ],
    ),
  );
}

Widget libraryView(double el) {
  final iconBtn =
      buttons['icon'] as Widget Function(IconData, VoidCallback, double);

  return ValueListenableBuilder<List<Map<String, dynamic>>>(
    valueListenable: tracksList,
    builder: (_, list, __) {
      if (list.isEmpty) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              texts['library']!,
              style: TextStyle(
                color: colors['text'],
                fontSize: el * 1.2,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: el * .8),
            Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: el * 6),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      iconsMap['playlist']!,
                      size: el * 4,
                      color: colors['textDim'],
                    ),
                    SizedBox(height: el),
                    Text(
                      texts['noTracks']!,
                      style: TextStyle(
                        color: colors['textDim'],
                        fontSize: el * 1.05,
                      ),
                    ),
                    SizedBox(height: el * .6),
                    Text(
                      texts['importCta']!,
                      style: TextStyle(color: colors['textDim'], fontSize: el),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      }

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                texts['library']!,
                style: TextStyle(
                  color: colors['text'],
                  fontSize: el * 1.2,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              // текущая сортировка справа (иконка sort уже в topBar)
              Text(
                texts[currentSort] ?? '',
                style: TextStyle(color: colors['textDim'], fontSize: el),
              ),
            ],
          ),
          SizedBox(height: el * .8),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: list.length,
            separatorBuilder: (_, __) => SizedBox(height: el * .6),
            itemBuilder: (_, i) {
              final t = list[i];
              return InkWell(
                onTap: () {}, // позже: play
                borderRadius: BorderRadius.circular(el),
                child: Padding(
                  padding: EdgeInsets.all(el * .6),
                  child: Row(
                    children: [
                      Container(
                        width: el * 2.6,
                        height: el * 2.6,
                        decoration: BoxDecoration(
                          color: colors['accentDim'],
                          borderRadius: BorderRadius.circular(el),
                        ),
                      ),
                      SizedBox(width: el),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              t['title'] ?? '',
                              style: TextStyle(
                                color: colors['text'],
                                fontSize: el * 1.05,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(height: el * .2),
                            Text(
                              (t['artist'] ?? '').toString().isEmpty
                                  ? '—'
                                  : t['artist'],
                              style: TextStyle(
                                color: colors['textDim'],
                                fontSize: el,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: el),
                      iconBtn(iconsMap['more']!, () {}, el),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      );
    },
  );
}

Widget miniPlayer(double el) {
  final iconBtn =
      buttons['icon'] as Widget Function(IconData, VoidCallback, double);

  return Row(
    children: [
      Container(
        width: el * 3.2,
        height: el * 3.2,
        decoration: BoxDecoration(
          color: colors['accentDim'],
          borderRadius: BorderRadius.circular(el),
        ),
      ),
      SizedBox(width: el),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              texts['trackSample']!,
              style: TextStyle(color: colors['text'], fontSize: el),
            ),
            Text(
              texts['artistSample']!,
              style: TextStyle(color: colors['textDim'], fontSize: el * .95),
            ),
          ],
        ),
      ),
      iconBtn(iconsMap['play']!, () {}, el),
    ],
  );
}

/* ========= actions ========= */

void openAddMenu(BuildContext ctx, double el) {
  showModalBottomSheet(
    context: ctx,
    backgroundColor: Colors.transparent,
    builder: (_) => Padding(
      padding: EdgeInsets.all(el * 1.2),
      child: glass(
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(
                Icons.file_upload_rounded,
                color: Colors.white,
              ),
              title: Text(
                texts['importFiles']!,
                style: TextStyle(color: colors['text']),
              ),
              onTap: () async {
                Navigator.pop(ctx);
                await pickAndImportFiles(ctx);
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.folder_open_rounded,
                color: Colors.white,
              ),
              title: Text(
                texts['importFolder']!,
                style: TextStyle(color: colors['text']),
              ),
              onTap: () {
                Navigator.pop(ctx);
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.playlist_add_rounded,
                color: Colors.white,
              ),
              title: Text(
                texts['createPlaylist']!,
                style: TextStyle(color: colors['text']),
              ),
              onTap: () {
                Navigator.pop(ctx);
              },
            ),
          ],
        ),
        el,
      ),
    ),
  );
}

void openSortSheet(BuildContext ctx, double el) {
  final opts = [
    texts['byName']!,
    texts['byArtist']!,
    texts['byDate']!,
    texts['byDuration']!,
  ];
  showModalBottomSheet(
    context: ctx,
    backgroundColor: Colors.transparent,
    builder: (_) => Padding(
      padding: EdgeInsets.all(el * 1.2),
      child: glass(
        ListView.builder(
          shrinkWrap: true,
          itemCount: opts.length,
          itemBuilder: (_, i) => ListTile(
            title: Text(opts[i], style: TextStyle(color: colors['text'])),
            onTap: () {
              Navigator.pop(ctx);
              final ids = ['byName', 'byArtist', 'byDate', 'byDuration'];
              setSort(ids[i]);
            },
          ),
        ),
        el,
      ),
    ),
  );
}

// поддерживаемые расширения
final List<String> audioExt = ['mp3', 'm4a', 'aac', 'wav', 'flac', 'ogg'];

// боксы hive (ленивая инициализация)
Box? tracksBox, playlistsBox, prefsBox;

// локальный стор для UI
final tracksList = ValueNotifier<List<Map<String, dynamic>>>([]);
String currentSort = 'byDate'; // по умолчанию

Future<void> ensureBoxes() async {
  if (tracksBox != null) return;
  await Hive.initFlutter();
  tracksBox = await Hive.openBox('tracksBox');
  playlistsBox = await Hive.openBox('playlistsBox');
  prefsBox = await Hive.openBox('prefsBox');

  currentSort = prefsBox!.get('sort', defaultValue: 'byDate');
  _reloadTracks();
}

void setSort(String id) {
  currentSort = id;
  prefsBox?.put('sort', id);
  _reloadTracks();
}

void _reloadTracks() {
  final all = List<Map<String, dynamic>>.from(
    tracksBox?.values.cast<Map>() ?? const [],
  );
  all.sort((a, b) {
    switch (currentSort) {
      case 'byName':
        return (a['title'] ?? '').toString().toLowerCase().compareTo(
          (b['title'] ?? '').toString().toLowerCase(),
        );
      case 'byArtist':
        return (a['artist'] ?? '').toString().toLowerCase().compareTo(
          (b['artist'] ?? '').toString().toLowerCase(),
        );
      case 'byDuration':
        return (a['duration'] ?? 0).compareTo(b['duration'] ?? 0);
      case 'byDate':
      default:
        return (b['addedAt'] ?? 0).compareTo(a['addedAt'] ?? 0);
    }
  });
  tracksList.value = all;
}

///Import files
Future<void> pickAndImportFiles(BuildContext ctx) async {
  // 1. сначала спрашиваем файлы
  final res = await FilePicker.platform.pickFiles(
    type: FileType.custom,
    allowedExtensions: audioExt,
    allowMultiple: true,
    withData: kIsWeb, // на десктопе false, на веб true
  );

  if (res == null || res.files.isEmpty) {
    // юзер просто закрыл диалог
    return;
  }

  // 2. открываем hive боксы (если еще не открыты)
  await ensureBoxes();

  // 3. пишем треки в боксы
  for (final f in res.files) {
    final path = f.path; // на Windows это нормальный путь
    final bytes = f.bytes; // на Windows обычно null, на Web не null

    // защита от мусора
    if (path == null && (bytes == null || bytes.isEmpty)) continue;
    if (_existsFile(f)) continue;
    if (!_isAudio(path ?? f.name)) continue;

    final now = DateTime.now().millisecondsSinceEpoch;
    final id = _fastId(path ?? f.name, now);
    final name = p.basenameWithoutExtension(path ?? f.name);

    final track = <String, dynamic>{
      'id': id,
      'source': kIsWeb ? 'web' : 'fs',
      'path': path ?? '',
      'name': f.name,
      'size': f.size,
      'title': name,
      'artist': '',
      'album': '',
      'duration': 0,
      'art': null,
      'addedAt': now,
    };

    await tracksBox!.put(id, track);
  }

  _reloadTracks();
}

bool _isAudio(String path) {
  final ext = p.extension(path).replaceFirst('.', '').toLowerCase();
  return audioExt.contains(ext);
}

bool _existsFile(PlatformFile f) {
  final vals = tracksBox?.values.cast<Map>() ?? const Iterable<Map>.empty();

  if (f.path != null) {
    // десктоп / мобилки: проверяем по пути
    return vals.any((e) => (e['path'] ?? '') == f.path);
  }

  // веб (у нас kIsWeb=false на Windows, но оставим логично)
  return vals.any(
    (e) => (e['name'] ?? '') == f.name && (e['size'] ?? -1) == f.size,
  );
}

String _fastId(String path, int seed) {
  // простой быстрый id без пакетов
  final s = '${path.length}_${path.hashCode}_$seed';
  return s;
}
